//: Playground - noun: a place where people can play

import UIKit

 class imagefilter {
 var image : UIImage
 init (image : UIImage) {
 self.image = image
 }
 func applysomefilters(filters:Array<String>) -> RGBAImage {
 let rgbaImage = RGBAImage(image: image)!
 for filter in filters {
 switch(filter){
 case "IncreaseTransparency %50": for y in 0..<rgbaImage.height {
 for x in 0..<rgbaImage.width {
 let index = y * rgbaImage.width + x
 var pixel = rgbaImage.pixels[index]
 pixel.alpha = UInt8(pixel.alpha/2)
 rgbaImage.pixels[index] = pixel
 }
 }
 case "IncreaseRed %100": for y in 0..<rgbaImage.height {
 for x in 0..<rgbaImage.width {
 let index = y * rgbaImage.width + x
 var pixel = rgbaImage.pixels[index]
 pixel.red = UInt8(min(255,Int(pixel.red)*2))
 rgbaImage.pixels[index] = pixel
 }
 }
 case "IncreaseGreen %100": for y in 0..<rgbaImage.height {
 for x in 0..<rgbaImage.width {
 let index = y * rgbaImage.width + x
 var pixel = rgbaImage.pixels[index]
 pixel.green = UInt8(min(255,Int(pixel.green)*2))
 rgbaImage.pixels[index] = pixel
 }
 }
 case "IncreaseBlue %100": for y in 0..<rgbaImage.height {
 for x in 0..<rgbaImage.width {
 let index = y * rgbaImage.width + x
 var pixel = rgbaImage.pixels[index]
 pixel.blue = UInt8(min(255,Int(pixel.blue)*2))
 rgbaImage.pixels[index] = pixel
 }
 }
 case "DecreaseRed %100": for y in 0..<rgbaImage.height {
 for x in 0..<rgbaImage.width {
 let index = y * rgbaImage.width + x
 var pixel = rgbaImage.pixels[index]
 pixel.red = UInt8(0)
 rgbaImage.pixels[index] = pixel
 }
 }
 case "DecreaseGreen %100": for y in 0..<rgbaImage.height {
 for x in 0..<rgbaImage.width {
 let index = y * rgbaImage.width + x
 var pixel = rgbaImage.pixels[index]
 pixel.green = UInt8(0)
 rgbaImage.pixels[index] = pixel
 }
 }
 case "DecreaseBlue %100": for y in 0..<rgbaImage.height {
 for x in 0..<rgbaImage.width {
 let index = y * rgbaImage.width + x
 var pixel = rgbaImage.pixels[index]
 pixel.blue = UInt8(0)
 rgbaImage.pixels[index] = pixel
 }
 }
 default : rgbaImage
 }
 }
 return rgbaImage
 }
 }
 
 let image = UIImage(named: "sample")
 var myImageProcessor = imagefilter(image: image!)
 myImageProcessor.applysomefilters(["IncreaseTransparency %50","IncreaseRed %100"]).toUIImage()
 myImageProcessor.applysomefilters(["IncreaseBlue %100"]).toUIImage()
 myImageProcessor.applysomefilters(["DecreaseGreen %100"]).toUIImage()
 myImageProcessor.applysomefilters(["IncreaseRed %100","IncreaseGreen %100","DecreaseBlue %100"]).toUIImage()
 myImageProcessor.applysomefilters(["IncreaseTransparency %50","IncreaseRed %100","DecreaseGreen %100","IncreaseBlue %100"]).toUIImage()
